exports.moduleLoaded = function() {
    return 'This is LoadMyGDF.js';
};