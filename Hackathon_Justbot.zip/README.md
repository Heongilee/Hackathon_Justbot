# Hackathon_Justbot
2020년 제8회 세종대학교 SW·AI 해커톤 팀 '그저봇'

### * 팀원 구성  
김영현(portfolioExpert)  kyh7518@gmail.com  
정재웅(weedsib123)       jaeung95@gmail.com  
이헌기(Heongilee)        gjsrl1@gmail.com  
  
### * 개발 주제 :  
소융대 학과  조교 서비스를 위한 AI챗봇  
  
### * 개발 스펙 :  
##### FE :  
반응형 웹 기반(html/css/js/jQuery)  
  
  
##### BE :  
Google Dialog flow(자연어 처리 플랫폼), Node.js (서버)  
